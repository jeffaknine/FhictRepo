/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxbusy;

import java.util.Calendar;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;

import javafx.stage.Stage;
/**
 *
 * @author Joris
 */
public class BusyApplication extends Application {

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    

    private Button btn1, btn2;    
    private Label label1;
    private VBox vBox;
    private HBox hBox;
    private Scene scene;
    private BusyWorker myBusyWorker;
    @Override
    public void start(Stage primaryStage) {
        label1 = new Label();
        btn1 = new Button();
        btn2 = new Button();
        vBox = new VBox(8);
        hBox = new HBox(8);
        myBusyWorker = new BusyWorker(5000);
        
        btn1.setText("show current time");
        btn2.setText("Work");
        btn1.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                label1.setText(Calendar.getInstance().getTime().toString()
                + "; milliseconds: "
                + Calendar.getInstance().get(Calendar.MILLISECOND));
            }
            
        });
        
        btn2.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                myBusyWorker.busyJob();
            }
            
        });
        // TODO: VBox, Scene, Stage actions        
        hBox.getChildren().add(btn2);
        vBox.getChildren().addAll(btn1,label1,hBox);
        vBox.setPadding(new Insets(80,80,80,80));
        vBox.setSpacing(30);
        scene = new Scene(vBox,300,300);
        primaryStage.setTitle("Busy app");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
