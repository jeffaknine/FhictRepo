#include "MeasurementSeries.h"
#include <iostream>
using namespace std;

MeasurementSeries::MeasurementSeries(string n)
	:name("")
	,count(0)
	,measurementData[MaxMeasurementValues]
{
}


string MeasurementSeries::getName()
{
	return name;
}

void MeasurementSeries::setName(string name)
{
	name = name;
}

bool MeasurementSerie::isFull()
{
	int check = 0;
	for (int i = 0; i < 10; ++i)
	{
		if (measurementData[i] != 0 )
		{
			check++;
		}
	}

	if (check == 10)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

// void MeasurementSerie::addValue(int value)
// {
// 	if (MeasurementSerie::isFull() == true)
// 	{
		
// 	}
// }

bool MeasurementSerie::valueExists(int value)
{
	int i = 0;
	while(measurementData[i] != value)
	{
		i++;
	}
	
	if (measurementData[i] == value)
	{
		return true;
	}

}

int MeasurementSerie::getValue(int index)
{
	if (index >= 0 && index < 10)
	{
		return measurementData[index];
	}
	else return -1;
}

// void MeasurementSerie::getNrMeasurements(int& number)
// {

// }