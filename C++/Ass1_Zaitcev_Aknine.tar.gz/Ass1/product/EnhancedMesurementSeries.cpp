// #include "MeasurementSeries.h"
// #include <iostream>
// using namespace std;

// EnhancedMeasurementSeries::EnhancedMeasurementSeries(string name)
// :MeasurementSeries(name)
// {
// }

// int EnhancedMeasurementSeries::getNrTimes(int value)
// {

// }

// void EnhancedMeasurementSeries::addSerie(const MeasurementSeries* serie)
// {

// }

// void EnhancedMeasurementSeries::addValue(int value)
// {

// }

// int EnhancedMeasurementSeries::getNrDifferentValues()
// {

// }