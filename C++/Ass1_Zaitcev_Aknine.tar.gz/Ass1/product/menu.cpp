#include "MeasurementSeries.h"
#include "EnhancedMeasurementSeries.h"
#include <iostream>

#include <string>
using namespace std;

void showMenu( void )
{
	cout << ("\n\nMeasurements MENU");
	cout << ("\n===========================");
	cout << ("\n(1) Show all values");
	cout << ("\n(2) Add a measurement value.");
	cout << ("\n(3) Test if another measurement value can be added");
	cout << ("\n(4) Show how often a certain value is stored");
	cout << ("\n(5) Show the measurement series' name");
	cout << ("\n(6) Change the measurement series' name");
	cout << ("\n(7) Test if a certain value is stored");
	// cout << ("\n(8) Add measurement series m1 with value 8 and 9");
	// cout << ("\n(9) Add enhanced measurement series mx1 with values -2 and -3");
	// cout << ("\n(10) Show the number of different values");
	cout << ("\n(8) QUIT");
	cout <<  ("\n\nChoice : ");
}

void showAllValues( MeasurementSeries myMeasurements )
{
	for (int i = 0; i < 10; ++i)
	{
		cout << "\nValue " << i << " = " << myMeasurements.getValue(i);
	}
}
void case2(MeasurementSeries& myMeasurements)
{
	int addvalue = 0;
	if (myMeasurements.isFull() == true)
	{
		cout << "The array is full, no more measurement can be added" << endl;	
	}				
	else
	{
		cout << "Please enter the measurement value : "<<endl;
		cin >> addvalue;
		cin.ignore();
		myMeasurements.addValue(addvalue);
	}
}

void case3(MeasurementSeries myMeasurements)
{
	if (myMeasurements.isFull() == true)
	{
		cout << "The array is full, no more measurement can be added" << endl;
	}
	else
	{
		cout << "The array isn't full, some measurement can be added" << endl;	
	}
}

void case4(MeasurementSeries myMeasurements)
{	
	int number;
	cout << "Please enter a number :" << endl;
	cin >> number;
	cin.ignore();
	myMeasurements.getNrMeasurements(number);
	cout << number<<endl;
}


void case6(MeasurementSeries& myMeasurements)
{
	string name = "";
	cout << "Please enter the new measurement series' name :" << endl;
	getline(cin,name);
	myMeasurements.setName(name);
	cout << "New name is : " << myMeasurements.getName();
}

void case7(MeasurementSeries myMeasurements)
{
	int value = 0;
	cout << "Please enter the value you want to check :" << endl;
	cin >> value;
	cin.ignore();
	bool plop = myMeasurements.valueExists(value);
	if (plop == true)
	{
		cout << "Yes the value " << value << " is stored"<< endl;
	}
	else
	{
		cout << "No the value " << value << " is not stored" << endl;
	}
}


int main(void)
{
	
	bool quit = false;
	char choice = '\0';
	MeasurementSeries myMeasurements("Jeff");

	while (!quit)
	{
		showMenu();
		cin.get(choice);    // C++ style i/o: chapter 3 in book
        cin.ignore();       // C++ style i/o: chapter 3 in book

        switch (choice)
        {
        	case '1':
        	showAllValues(myMeasurements);
        	break;

        	case '2':
        	case2(myMeasurements);
        	break;

        	case '3':
        	case3(myMeasurements);
        	break;

        	case '4':
        	case4(myMeasurements);
        	break;

        	case '5':
        	cout << "Measurement Series' name is : " << myMeasurements.getName() <<endl;
        	break;

        	case '6':
        	case6(myMeasurements);
        	break;

        	case '7':
        	case7(myMeasurements);
        	break;

        	case '8':
        	quit = true;
        	break;
        	default:
        	cout << "\n\nI am terribly sorry for not understanding choice: " << choice;
        	break;
        }
    }
}