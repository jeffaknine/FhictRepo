// #ifndef ENHANCEDMEASUREMENTSERIES_H
// #define ENHANCEDMEASUREMENTSERIES_H

// class EnhancedMeasurementSeries : public MeasurementSeries
// {
// 	private:
// 		int nrDifferentValues;
// 	public:
// 		EnhancedMeasurementSeries(string name)
// 		/*	pre: -
// 			post: EnhancedMeasuremenetSeries has no measurement data, name is stored
// 		*/

// 		int getNrTimes(int value);
// 		/*	pre: -
// 			post: returns the number of times value is in <EnhancedMeasurementSeries>
// 		*/

// 		void addSerie(const MeasurementSeries* serie);
// 		/*	pre: -
// 			post: All values from series are added to <EnhancedMeasurementSeries>, nrDifferentValues is updated
// 		*/

// 		void addValue(int value);
// 		/*	pre: -
// 			post:value is added to <EnhancedMeasurementSeries>, nrDifferentValues is updated
// 		*/

// 		int getNrDifferentValues();
// 		/*	pre: -
// 			post: returns the number of different values in <EnhancedMeasurementSeries>
// 		*/

// };
// #endif